import os
import re
import tempfile
from datetime import datetime
from pathlib import Path

from dotenv import load_dotenv
from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, ContextTypes, filters
from PIL import Image, ImageOps, ImageEnhance
import pytesseract
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
from openpyxl.utils import get_column_letter

load_dotenv()
TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")

HEADERS = ["TGL", "START", "STOP", "KETERANGAN", "DRIVER", "PEMBERI TUGAS"]


def preprocess_image(image_path: str) -> str:
    """Bikin gambar lebih mudah dibaca OCR."""
    img = Image.open(image_path).convert("L")
    img = ImageOps.autocontrast(img)
    img = ImageEnhance.Sharpness(img).enhance(2.0)
    img = ImageEnhance.Contrast(img).enhance(1.8)
    out = image_path + "_clean.png"
    img.save(out)
    return out


def ocr_image(image_path: str) -> str:
    clean = preprocess_image(image_path)
    # ind+eng jika paket bahasa Indonesia tersedia; fallback ke eng bila tidak ada
    try:
        return pytesseract.image_to_string(Image.open(clean), lang="ind+eng", config="--psm 6")
    except Exception:
        return pytesseract.image_to_string(Image.open(clean), lang="eng", config="--psm 6")


def parse_header(text: str) -> dict:
    data = {"nama_driver": "", "nrp": "", "nopol": "", "kode_unit": "", "type_unit": "", "periode": ""}
    lines = [x.strip() for x in text.splitlines() if x.strip()]
    joined = "\n".join(lines)

    patterns = {
        "nama_driver": r"Nama\s*Driver\s*[:\-]?\s*(.+)",
        "nrp": r"NRP\s*[:\-]?\s*(.+)",
        "nopol": r"Nopol\s*[:\-]?\s*(.+)",
        "kode_unit": r"Kode\s*Unit\s*[:\-]?\s*(.+)",
        "type_unit": r"Typer?\s*Unit\s*[:\-]?\s*(.+)",
        "periode": r"Periode\s*[:\-]?\s*(.+)",
    }
    for key, pat in patterns.items():
        m = re.search(pat, joined, flags=re.I)
        if m:
            data[key] = m.group(1).strip()[:80]
    return data


def parse_rows(text: str):
    rows = []
    for raw in text.splitlines():
        line = raw.strip()
        # Tangkap baris yang diawali tanggal 1-31 lalu jam start/stop
        m = re.match(r"^(\d{1,2})\D+(\d{1,2}[.:]\d{2})\D+(\d{1,2}[.:]\d{2})\s+(.+)$", line)
        if not m:
            continue
        tgl, start, stop, ket = m.groups()
        start = start.replace(".", ":")
        stop = stop.replace(".", ":")
        rows.append([int(tgl), start, stop, ket.strip(), "", ""])
    return rows


def create_excel(header: dict, rows: list, raw_text: str, output_path: str):
    wb = Workbook()
    ws = wb.active
    ws.title = "Hasil OCR SKL"

    title_fill = PatternFill("solid", fgColor="B91C1C")
    header_fill = PatternFill("solid", fgColor="FDE68A")
    thin = Side(style="thin", color="555555")
    border = Border(left=thin, right=thin, top=thin, bottom=thin)

    ws.merge_cells("A1:F1")
    ws["A1"] = "HASIL OCR SURAT KESEPAKATAN LEMBUR"
    ws["A1"].font = Font(bold=True, size=14, color="FFFFFF")
    ws["A1"].fill = title_fill
    ws["A1"].alignment = Alignment(horizontal="center")

    info = [
        ("Nama Driver", header.get("nama_driver", "")),
        ("NRP", header.get("nrp", "")),
        ("Nopol", header.get("nopol", "")),
        ("Kode Unit", header.get("kode_unit", "")),
        ("Type Unit", header.get("type_unit", "")),
        ("Periode", header.get("periode", "")),
    ]
    r = 3
    for label, value in info:
        ws.cell(r, 1, label).font = Font(bold=True)
        ws.cell(r, 2, value)
        r += 1

    start_row = 11
    for col, h in enumerate(HEADERS, 1):
        c = ws.cell(start_row, col, h)
        c.font = Font(bold=True)
        c.fill = header_fill
        c.alignment = Alignment(horizontal="center")
        c.border = border

    if rows:
        for i, row in enumerate(rows, start_row + 1):
            for col, val in enumerate(row, 1):
                c = ws.cell(i, col, val)
                c.border = border
                c.alignment = Alignment(vertical="top", wrap_text=True)
    else:
        ws.cell(start_row + 1, 1, "OCR belum berhasil membaca tabel. Cek sheet RAW OCR lalu rapikan manual.")

    raw_ws = wb.create_sheet("RAW OCR")
    raw_ws["A1"] = raw_text
    raw_ws["A1"].alignment = Alignment(wrap_text=True, vertical="top")
    raw_ws.column_dimensions["A"].width = 120
    raw_ws.row_dimensions[1].height = 500

    widths = [8, 12, 12, 55, 18, 18]
    for idx, width in enumerate(widths, 1):
        ws.column_dimensions[get_column_letter(idx)].width = width
    ws.freeze_panes = "A12"
    wb.save(output_path)


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "Halo. Kirim foto SKL, nanti saya baca OCR dan kirim balik file Excel.\n"
        "Tips: foto harus lurus, terang, tidak blur, dan usahakan pakai scan Microsoft Lens/Adobe Scan."
    )


async def handle_photo(update: Update, context: ContextTypes.DEFAULT_TYPE):
    msg = await update.message.reply_text("Foto diterima, sedang dibaca OCR...")
    photo = update.message.photo[-1]
    tg_file = await context.bot.get_file(photo.file_id)

    with tempfile.TemporaryDirectory() as tmpdir:
        img_path = str(Path(tmpdir) / "skl.jpg")
        await tg_file.download_to_drive(img_path)

        raw_text = ocr_image(img_path)
        header = parse_header(raw_text)
        rows = parse_rows(raw_text)

        out_path = str(Path(tmpdir) / f"hasil_skl_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx")
        create_excel(header, rows, raw_text, out_path)

        await msg.edit_text(f"Selesai. Terbaca {len(rows)} baris tabel. Ini file Excel-nya.")
        await update.message.reply_document(document=open(out_path, "rb"), filename=Path(out_path).name)


def main():
    if not TOKEN:
        raise RuntimeError("TELEGRAM_BOT_TOKEN belum diisi di file .env")
    app = ApplicationBuilder().token(TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(MessageHandler(filters.PHOTO, handle_photo))
    app.run_polling()


if __name__ == "__main__":
    main()
