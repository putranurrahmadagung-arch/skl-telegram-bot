BOT TELEGRAM FOTO SKL KE EXCEL

1) Buat bot dari Telegram:
   - Buka @BotFather
   - Ketik /newbot
   - Ikuti instruksi sampai dapat TOKEN

2) Install Python di laptop/PC.

3) Install Tesseract OCR:
   Windows: install Tesseract OCR dari UB Mannheim, lalu centang language Indonesia bila ada.
   Android/HP saja: paling mudah jalankan di Termux, tapi lebih ribet. Disarankan laptop/PC/VPS.

4) Buka folder ini di CMD/Terminal, lalu jalankan:
   pip install -r requirements.txt

5) Copy file .env.example menjadi .env
   Isi TOKEN dari BotFather:
   TELEGRAM_BOT_TOKEN=token_kamu

6) Jalankan bot:
   python bot.py

7) Buka bot Telegram kamu, ketik /start, lalu kirim foto SKL.
   Bot akan kirim file Excel .xlsx.

CATATAN PENTING:
- Tulisan tangan tidak selalu terbaca sempurna.
- Untuk hasil lebih bagus, scan foto pakai Microsoft Lens / Adobe Scan dulu.
- Sheet RAW OCR disediakan agar hasil mentah OCR bisa dicek dan dirapikan.
